"""Single server entry point for AUCMR generation and automatic evaluation."""

from __future__ import annotations

import argparse
import copy
import importlib.util
import json
import logging
import os
import re
import shutil
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
DEFAULT_CONFIG = ROOT / "experiment.json"
FULL = "AUCMR (CREST full)"
WITHOUT_DRA = "CREST w/o cross-slot"
BASELINES = {
    "LVLM-Direct",
    "TextRAG-Elaborate",
    "VDocRAG-Elaborate",
    "ViDoRAG-Elaborate",
    "ReAct-Elaborate",
}
ALL_METHODS = {FULL, WITHOUT_DRA, *BASELINES}


@dataclass
class GuideAction:
    stage: str
    status: str
    message: str
    command: str | None = None
    branches: list[str] | None = None


def load_config(path: str) -> tuple[dict, Path]:
    config_path = Path(path).expanduser().resolve()
    with config_path.open("r", encoding="utf-8") as f:
        config = json.load(f)
    if not isinstance(config, dict):
        raise ValueError("The config root must be a JSON object")
    os.environ["AUCMR_CONFIG"] = str(config_path)
    # Configure the Hub endpoint before transformers/peft/huggingface_hub are
    # imported.  This keeps model downloads reproducible on servers where the
    # official Hub is unreachable, while still allowing an explicit shell
    # environment variable to take precedence.
    hf_endpoint = str(config.get("runtime", {}).get("hf_endpoint", "")).strip()
    if hf_endpoint:
        os.environ.setdefault("HF_ENDPOINT", hf_endpoint.rstrip("/"))
    return config, config_path


def resolve_path(config_path: Path, value: str) -> Path:
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (config_path.parent / path).resolve()


def selected_methods(config: dict, cli_methods: list[str] | None) -> list[str]:
    methods = cli_methods or config.get("experiment", {}).get("methods", [])
    unknown = set(methods) - ALL_METHODS
    if unknown:
        raise ValueError(f"Unknown method(s): {sorted(unknown)}")
    return methods


def preflight(config: dict, config_path: Path, methods: list[str]) -> int:
    errors: list[str] = []
    warnings: list[str] = []
    for key in ("output", "images", "embedder", "linucb", "pca"):
        if key not in config.get("paths", {}):
            errors.append(f"missing paths.{key}")
    for key in ("llm", "lvlm", "nli_judge", "nli_vision_judge", "l2_judge"):
        model = config.get("models", {}).get(key, {})
        for field in ("base_url", "model_name", "api_key_env"):
            if not model.get(field):
                errors.append(f"missing models.{key}.{field}")
        if str(model.get("model_name", "")).startswith("CHANGE_ME"):
            warnings.append(f"models.{key}.model_name still uses a placeholder")
        env_name = model.get("api_key_env")
        if env_name and not os.environ.get(env_name):
            warnings.append(f"environment variable {env_name} is empty")
    registry_methods = {FULL, WITHOUT_DRA, "ViDoRAG-Elaborate", "ReAct-Elaborate"}
    needed_assets: set[str] = set()
    if set(methods) & registry_methods:
        needed_assets.update(("linucb", "pca", "embedder"))
    if "TextRAG-Elaborate" in methods:
        needed_assets.add("embedder")
    for key in needed_assets:
        value = config.get("paths", {}).get(key)
        if value and not resolve_path(config_path, value).exists():
            errors.append(f"paths.{key} does not exist: {resolve_path(config_path, value)}")
    use_cases = config.get("experiment", {}).get("use_cases", [])
    if not use_cases:
        errors.append("experiment.use_cases is empty")
    for i, item in enumerate(use_cases):
        for field in ("project", "actor", "use_case"):
            if not item.get(field):
                errors.append(f"experiment.use_cases[{i}].{field} is missing")
        if {"LVLM-Direct", "VDocRAG-Elaborate"} & set(methods):
            image_dir = resolve_path(config_path, config["paths"]["images"]) / item.get("project", "")
            if not image_dir.is_dir():
                errors.append(f"page-image directory does not exist: {image_dir}")

    required = ["openai", "json_repair", "PIL"]
    if set(methods) & (registry_methods | {"TextRAG-Elaborate"}):
        required.extend(["numpy", "scipy", "torch", "transformers", "pymilvus"])
    if "VDocRAG-Elaborate" in methods:
        required.extend(["numpy", "torch", "transformers", "peft"])
    for module in required:
        if importlib.util.find_spec(module) is None:
            errors.append(f"missing Python dependency: {module}")
    if "TextRAG-Elaborate" in methods and not config.get("services", {}).get("text_milvus", {}).get("collection_template"):
        errors.append("TextRAG-Elaborate requires services.text_milvus.collection_template")
    vendor_root = config_path.parent / "eval" / "vendor"
    if "VDocRAG-Elaborate" in methods:
        if not (vendor_root / "VDocRAG" / "src" / "vdocrag").is_dir():
            errors.append("VDocRAG official vendor source is missing")
        for field in ("base_model", "retriever_lora", "device", "dtype"):
            if not config.get("baselines", {}).get("vdocrag", {}).get(field):
                errors.append(f"VDocRAG-Elaborate requires baselines.vdocrag.{field}")
        for module in ("peft", "PIL"):
            if importlib.util.find_spec(module) is None:
                errors.append(f"VDocRAG-Elaborate missing Python dependency: {module}")
        vdocrag = config.get("baselines", {}).get("vdocrag", {})
        if str(vdocrag.get("dtype", "")) not in {"float16", "bfloat16", "float32"}:
            errors.append("baselines.vdocrag.dtype must be float16, bfloat16, or float32")
        attention = vdocrag.get("attn_implementation") or "eager"
        if attention not in {"eager", "sdpa", "flash_attention_2"}:
            errors.append(
                "baselines.vdocrag.attn_implementation must be eager, sdpa, or flash_attention_2"
            )
        if vdocrag.get("attn_implementation") == "flash_attention_2" and importlib.util.find_spec("flash_attn") is None:
            errors.append(
                "baselines.vdocrag.attn_implementation=flash_attention_2 requires flash-attn; "
                "set it to null to use the model default"
            )
    if "ViDoRAG-Elaborate" in methods:
        if not (vendor_root / "ViDoRAG" / "vidorag_agents.py").is_file():
            errors.append("ViDoRAG official vendor source is missing")
        else:
            try:
                # Exercise both namespaces together.  A file-existence check
                # alone cannot detect collisions between ViDoRAG's ``utils``
                # package and AUCMR's own retrieval utilities.
                importlib.import_module("eval.vendor.vidorag_adapter")
                importlib.import_module("eval.vendor.ViDoRAG.vidorag_agents")
                importlib.import_module("utils.retrieval")
            except ImportError as exc:
                errors.append(f"ViDoRAG-Elaborate import check failed: {exc}")
        vidorag = config.get("baselines", {}).get("vidorag", {})
        candidate_top_k = int(vidorag.get("candidate_top_k", 10))
        if not 1 <= candidate_top_k <= 20:
            errors.append("baselines.vidorag.candidate_top_k must be between 1 and 20")
        if int(vidorag.get("max_rounds", 5)) <= 0:
            errors.append("baselines.vidorag.max_rounds must be positive")

    print(f"Config: {config_path}")
    print(f"Methods: {', '.join(methods)}")
    print(f"Use cases: {len(use_cases)}")
    for item in warnings:
        print(f"WARNING: {item}")
    for item in errors:
        print(f"ERROR: {item}")
    print("Preflight: PASS" if not errors else f"Preflight: FAIL ({len(errors)} error(s))")
    return 0 if not errors else 2


def text_preflight(config: dict, config_path: Path, projects: list[str] | None = None) -> int:
    """Validate text-index inputs without invoking MinerU, models, or Milvus."""
    errors: list[str] = []
    warnings: list[str] = []
    text_cfg = config.get("text_pipeline", {})
    documents = text_cfg.get("documents", [])
    selected = set(projects or [])
    if not documents:
        errors.append("text_pipeline.documents is empty")
    configured_projects = {str(item.get("project", "")) for item in documents}
    unknown = selected - configured_projects
    if unknown:
        errors.append(f"unknown text-pipeline project(s): {sorted(unknown)}")
    documents = [item for item in documents if not selected or item.get("project") in selected]

    template = config.get("services", {}).get("text_milvus", {}).get("collection_template")
    if not template or "{project}" not in str(template):
        errors.append("services.text_milvus.collection_template must contain {project}")
    if not config.get("services", {}).get("milvus", {}).get("uri"):
        errors.append("missing services.milvus.uri")
    for field in ("text_work", "embedder"):
        if not config.get("paths", {}).get(field):
            errors.append(f"missing paths.{field}")
    embedder = config.get("paths", {}).get("embedder")
    if embedder and not resolve_path(config_path, embedder).exists():
        errors.append(f"paths.embedder does not exist: {resolve_path(config_path, embedder)}")

    mineru_needed = False
    identities: set[tuple[str, str]] = set()
    from pipelines.text_index import find_content_list
    for i, item in enumerate(documents):
        for field in ("project", "file_name", "pdf", "page_images", "parse_dir"):
            if not item.get(field):
                errors.append(f"text_pipeline.documents[{i}].{field} is missing")
        if not all(item.get(field) for field in ("project", "file_name", "pdf", "parse_dir")):
            continue
        identity = (str(item["project"]), str(item["file_name"]))
        if identity in identities:
            errors.append(f"duplicate text document identity: {identity}")
        identities.add(identity)
        pdf = resolve_path(config_path, item["pdf"])
        parse_dir = resolve_path(config_path, item["parse_dir"])
        if not pdf.is_file():
            errors.append(f"PDF does not exist: {pdf}")
        if find_content_list(parse_dir, pdf.stem) is None:
            mineru_needed = True

    configured_names: dict[str, set[str]] = {}
    for item in documents:
        configured_names.setdefault(str(item.get("project", "")), set()).add(
            str(item.get("file_name", ""))
        )
    for use_case in config.get("experiment", {}).get("use_cases", []):
        project = str(use_case.get("project", ""))
        if project not in configured_names:
            continue
        expected = set(use_case.get("file_names") or [project])
        missing = expected - configured_names[project]
        if missing:
            errors.append(
                f"project {project} is missing text_pipeline documents for file_names: {sorted(missing)}"
            )

    command = str(text_cfg.get("mineru", {}).get("command", "mineru"))
    if mineru_needed and shutil.which(command) is None:
        errors.append(f"MinerU command is not available: {command}")
    for module in ("openai", "fitz", "torch", "transformers", "pymilvus"):
        if importlib.util.find_spec(module) is None:
            errors.append(f"missing Python dependency: {module}")
    try:
        chunk_size = int(text_cfg.get("chunk_size", 800))
        overlap = int(text_cfg.get("chunk_overlap", 0))
        if chunk_size <= 0 or overlap < 0 or overlap >= chunk_size:
            raise ValueError
        if int(text_cfg.get("embedding_dimension", 128)) <= 0:
            raise ValueError
        if int(text_cfg.get("insert_batch_rows", 2000)) <= 0:
            raise ValueError
        if int(text_cfg.get("coarse_candidates", 100)) <= 0:
            raise ValueError
    except (TypeError, ValueError):
        errors.append("invalid numeric value in text_pipeline chunk/vector/batch/search settings")
    lvlm = config.get("models", {}).get("lvlm", {})
    if not lvlm.get("base_url"):
        errors.append("missing models.lvlm.base_url")
    if not lvlm.get("model_name"):
        errors.append("missing models.lvlm.model_name")
    if str(lvlm.get("model_name", "")).startswith("CHANGE_ME"):
        warnings.append("models.lvlm.model_name still uses a placeholder")
    key_env = lvlm.get("api_key_env")
    if key_env and not os.environ.get(key_env):
        warnings.append(f"environment variable {key_env} is empty")

    print(f"Config: {config_path}")
    print(f"Text projects: {', '.join(sorted(selected or configured_projects))}")
    print(f"Documents: {len(documents)}")
    for item in warnings:
        print(f"WARNING: {item}")
    for item in errors:
        print(f"ERROR: {item}")
    print("Text preflight: PASS" if not errors else f"Text preflight: FAIL ({len(errors)} error(s))")
    return 0 if not errors else 2


def run_text_build(config: dict, config_path: Path, projects: list[str] | None,
                   recreate: bool, force_mineru: bool) -> None:
    from pipelines.text_index import build_text_indexes

    summaries = build_text_indexes(
        config, config_path, recreate=recreate,
        force_mineru=force_mineru, projects=projects,
    )
    print(json.dumps(summaries, ensure_ascii=False, indent=2))


def run_image_build(config: dict, config_path: Path, projects: list[str] | None) -> None:
    """Submit missing page-image collections without ever overwriting one."""
    selected = set(projects or [])
    documents = [
        item for item in config.get("text_pipeline", {}).get("documents", [])
        if not selected or str(item.get("project")) in selected
    ]
    configured = {str(item.get("project")) for item in documents}
    unknown = selected - configured
    if unknown:
        raise ValueError(f"Unknown image project(s): {sorted(unknown)}")
    if not documents:
        raise ValueError("No configured documents selected for image indexing")

    # A zero-row collection may still have a running/failed bulk-import job. It
    # must be inspected explicitly instead of being silently appended to.
    for project in sorted(configured):
        state = _collection_status(config, project, set())
        if not state.get("reachable"):
            raise RuntimeError(f"Milvus is unreachable: {state.get('error')}")
        if state.get("exists"):
            raise RuntimeError(
                f"Refusing to import into existing image collection {project!r} "
                f"(row_count={state.get('rows', 0)}). Check the existing bulk-import job."
            )

    from pipelines.preprocess_minio_multi_img import preprocess_multiImg
    from services.model_registry import registry

    for document in documents:
        project = str(document["project"])
        image_dir = resolve_path(config_path, str(document["page_images"]))
        if not image_dir.is_dir():
            raise FileNotFoundError(f"Page-image directory does not exist: {image_dir}")
        job_id = preprocess_multiImg(
            output_dir=str(image_dir),
            pdf_name=str(document["file_name"]),
            embeder=registry.embeder,
            collection_name=project,
        )
        payload = {
            "project": project,
            "file_name": str(document["file_name"]),
            "job_id": str(job_id),
            "monitor_command": (
                f"python -m pipelines.check_progress {job_id} "
                f"--project {project} --watch"
            ),
        }
        job_root = resolve_path(
            config_path, str(config.get("paths", {}).get("image_work", "data/image_pipeline_jobs")),
        )
        job_root.mkdir(parents=True, exist_ok=True)
        (job_root / f"{project}.json").write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8",
        )
        print(json.dumps(payload, ensure_ascii=False, indent=2))


def run_vdocrag_build(config: dict, projects: list[str] | None) -> None:
    """Build/reuse official VDocRetriever page-embedding caches."""
    from eval.vendor.vdocrag_adapter import corpus_embeddings, get_runtime

    selected = set(projects or [])
    use_cases = config.get("experiment", {}).get("use_cases", [])
    known = {str(item["project"]) for item in use_cases}
    unknown = selected - known
    if unknown:
        raise ValueError(f"Unknown VDocRAG project(s): {sorted(unknown)}")
    runtime = get_runtime()
    summaries = []
    seen: set[tuple[str, tuple[str, ...]]] = set()
    for item in use_cases:
        project = str(item["project"])
        if selected and project not in selected:
            continue
        file_names = [str(value) for value in (item.get("file_names") or [project])]
        identity = (project, tuple(file_names))
        if identity in seen:
            continue
        seen.add(identity)
        paths, embeddings = corpus_embeddings(project, file_names, runtime)
        summaries.append({
            "project": project,
            "file_names": file_names,
            "pages": len(paths),
            "embedding_shape": list(embeddings.shape),
        })
    print(json.dumps(summaries, ensure_ascii=False, indent=2))


def _collection_status(config: dict, name: str, required_fields: set[str]) -> dict:
    try:
        from pymilvus import MilvusClient

        milvus = config.get("services", {}).get("milvus", {})
        client = MilvusClient(uri=str(milvus.get("uri", "")), token=milvus.get("token") or None)
        if not client.has_collection(collection_name=name, timeout=5):
            return {"reachable": True, "exists": False, "rows": 0, "schema_ok": False}
        description = client.describe_collection(collection_name=name, timeout=5)
        fields = {
            str(field.get("name")) for field in description.get("fields", [])
            if isinstance(field, dict)
        }
        stats = client.get_collection_stats(collection_name=name, timeout=5)
        rows = int(stats.get("row_count", 0))
        return {
            "reachable": True, "exists": True, "rows": rows,
            "schema_ok": required_fields <= fields,
            "missing_fields": sorted(required_fields - fields),
        }
    except Exception as exc:
        return {"reachable": False, "error": str(exc)}


def _configured_use_case_ids(config: dict) -> set[tuple[str, str, str]]:
    return {
        (str(item["project"]), str(item["use_case"]), str(item["actor"]))
        for item in config.get("experiment", {}).get("use_cases", [])
    }


def _result_counts(config: dict, output_root: Path) -> dict[str, dict]:
    expected = _configured_use_case_ids(config)
    projects = {item[0] for item in expected}
    found: dict[str, set[tuple[str, str, str]]] = {}
    if output_root.is_dir():
        for path in output_root.rglob("*.json"):
            if path.name.endswith("-evidence.json"):
                continue
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
            method = data.get("method")
            use_case = data.get("use_case_name")
            actor = data.get("actor")
            project = next((parent.name for parent in path.parents if parent.name in projects), None)
            if method and use_case and actor and project:
                evidence = path.with_name(path.stem + "-evidence.json")
                if evidence.is_file():
                    found.setdefault(str(method), set()).add((project, str(use_case), str(actor)))
    return {
        method: {
            "complete": len(found.get(method, set()) & expected),
            "expected": len(expected),
            "missing": [
                {"project": item[0], "use_case": item[1], "actor": item[2]}
                for item in sorted(expected - found.get(method, set()))
            ],
        }
        for method in selected_methods(config, None)
    }


def _latest_generation_mtime(output_root: Path) -> float:
    """Return the newest paired generation artifact timestamp, ignoring reports."""
    newest = 0.0
    if not output_root.is_dir():
        return newest
    for path in output_root.rglob("*.json"):
        if path.name.endswith("-evidence.json"):
            continue
        evidence = path.with_name(path.stem + "-evidence.json")
        if not evidence.is_file():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if data.get("method"):
            newest = max(newest, path.stat().st_mtime, evidence.stat().st_mtime)
    return newest


def guide(config: dict, config_path: Path, json_output: bool = False) -> int:
    """Read-only workflow state machine; never invokes models or changes data."""
    actions: list[GuideAction] = []
    details: dict[str, Any] = {}
    details["hf_endpoint"] = os.environ.get("HF_ENDPOINT", "https://huggingface.co")
    projects = sorted({str(item["project"]) for item in config["experiment"]["use_cases"]})

    required_modules = (
        "numpy", "scipy", "sklearn", "torch", "transformers", "openai",
        "pymilvus", "minio", "json_repair", "PIL", "fitz", "peft", "accelerate",
    )
    missing_modules = [name for name in required_modules if importlib.util.find_spec(name) is None]
    details["missing_python_modules"] = missing_modules
    environment_blocked = bool(missing_modules)
    if missing_modules:
        installable = [name for name in missing_modules if name != "torch"]
        command = (
            "python -m pip install -r requirements-rocm.txt" if installable else
            "python -c \"import torch; print(torch.__version__, torch.version.hip, torch.cuda.is_available())\""
        )
        branches = ["安装后再次运行 python run.py guide"]
        if "torch" in missing_modules:
            branches.append("torch 缺失时先按服务器 ROCm 版本安装官方 ROCm PyTorch，不能安装默认 CUDA wheel")
        else:
            branches.append("requirements-rocm.txt 不会重装已可用的 ROCm PyTorch")
        actions.append(GuideAction(
            "environment", "BLOCKED", f"缺少 Python 模块：{', '.join(missing_modules)}",
            command, branches,
        ))
    else:
        try:
            import torch
            details["torch"] = {
                "version": torch.__version__, "hip": torch.version.hip,
                "gpu_available": torch.cuda.is_available(),
            }
            if not torch.version.hip or not torch.cuda.is_available():
                environment_blocked = True
                actions.append(GuideAction(
                    "environment", "BLOCKED", "当前 Python 未检测到可用的 ROCm GPU。",
                    "python -c \"import torch; print(torch.__version__, torch.version.hip, torch.cuda.is_available())\"",
                    ["hip 应非空且最后一项应为 True", "修复 ROCm 环境后再次运行 guide"],
                ))
        except Exception as exc:
            environment_blocked = True
            actions.append(GuideAction("environment", "BLOCKED", f"PyTorch 检查失败：{exc}"))

    env_names = sorted({
        str(model.get("api_key_env"))
        for model in config.get("models", {}).values() if model.get("api_key_env")
    })
    missing_env = [name for name in env_names if not os.environ.get(name)]
    details["missing_api_key_env"] = missing_env
    if missing_env:
        actions.append(GuideAction(
            "credentials", "BLOCKED", f"尚未设置环境变量：{', '.join(missing_env)}",
            "export AUCMR_DEEPSEEK_API_KEY='...' && export AUCMR_DASHSCOPE_API_KEY='...'",
            ["不要把真实密钥写入 experiment.json", "设置后再次运行 guide"],
        ))

    paths_ok = True
    for document in config.get("text_pipeline", {}).get("documents", []):
        for field in ("pdf", "page_images"):
            path = resolve_path(config_path, document[field])
            if not path.exists():
                paths_ok = False
                actions.append(GuideAction("inputs", "BLOCKED", f"输入不存在：{path}"))
    for field in ("embedder", "linucb", "pca"):
        path = resolve_path(config_path, config["paths"][field])
        if not path.exists():
            paths_ok = False
            actions.append(GuideAction("inputs", "BLOCKED", f"资产不存在：{path}"))
    details["input_paths_ok"] = paths_ok

    if environment_blocked or missing_env or not paths_ok:
        next_action = actions[0]
    else:
        image_states = {
            project: _collection_status(
                config, project, {"patch_dense", "page_num", "page_path", "file_name"},
            ) for project in projects
        }
        details["image_collections"] = image_states
        unreachable = [name for name, state in image_states.items() if not state.get("reachable")]
        missing_images = [
            name for name, state in image_states.items()
            if state.get("reachable") and not state.get("exists")
        ]
        wrong_schema_images = [
            name for name, state in image_states.items()
            if state.get("reachable") and state.get("exists") and not state.get("schema_ok")
        ]
        empty_images = [
            name for name, state in image_states.items()
            if state.get("reachable") and state.get("exists")
            and state.get("schema_ok") and state.get("rows", 0) <= 0
        ]
        if unreachable:
            next_action = GuideAction(
                "milvus", "BLOCKED", f"无法连接 Milvus：{image_states[unreachable[0]].get('error')}",
                None, ["确认 Milvus 已启动且监听 127.0.0.1:19530", "修复后再次运行 guide"],
            )
        elif missing_images:
            project = missing_images[0]
            next_action = GuideAction(
                "image-index", "READY",
                f"图像 collection 不存在：{project}。从已准备的页面图片安全创建。",
                f"python run.py build-image --projects {project}",
                [
                    "命令会打印 job ID；按其提示监控 bulk-import，Completed 后再运行 guide",
                    "统一入口发现 collection 已存在时会拒绝追加，不会覆盖",
                ],
            )
        elif wrong_schema_images:
            project = wrong_schema_images[0]
            next_action = GuideAction(
                "image-index", "BLOCKED",
                f"图像 collection {project} 已有数据但 schema 不符合 AUCMR："
                f"缺少 {image_states[project].get('missing_fields', [])}。为避免破坏数据，不自动重建。",
                None, ["确认是否连到了正确的 Milvus 实例/collection", "需要重建时先备份并人工确认"],
            )
        elif empty_images:
            project = empty_images[0]
            job_file = resolve_path(
                config_path,
                str(config.get("paths", {}).get("image_work", "data/image_pipeline_jobs")),
            ) / f"{project}.json"
            job = {}
            if job_file.is_file():
                try:
                    job = json.loads(job_file.read_text(encoding="utf-8"))
                except Exception:
                    job = {}
            next_action = GuideAction(
                "image-import", "BLOCKED",
                f"图像 collection {project} 已创建但 row_count=0；等待或排查原 bulk-import。",
                job.get("monitor_command"),
                [
                    "状态为 Completed 后再次运行 guide",
                    "状态为 Failed 时保留错误日志，再决定是否删除空 collection 后重建",
                    "没有 job 留档时从原预处理终端找 job ID；不要直接重复导入",
                ],
            )
        else:
            text_states = {}
            template = str(config["services"]["text_milvus"]["collection_template"])
            for project in projects:
                name = template.format(project=project)
                text_states[name] = _collection_status(
                    config, name,
                    {"token_dense", "seq_id", "chunk_id", "page_num", "page_path", "file_name", "text"},
                )
            details["text_collections"] = text_states
            invalid_text = [
                name for name, state in text_states.items()
                if not state.get("reachable") or not state.get("exists")
                or not state.get("schema_ok") or state.get("rows", 0) <= 0
            ]
            if invalid_text:
                mineru_command = str(config["text_pipeline"]["mineru"].get("command", "mineru"))
                if shutil.which(mineru_command) is None:
                    next_action = GuideAction(
                        "mineru", "READY", "文本 collection 尚未建立，先安装 CPU 版 MinerU。",
                        "uv pip install \"mineru[pipeline]\"",
                        [
                            "安装后执行 mineru --version",
                            "再检查 ROCm：python -c \"import torch; print(torch.version.hip, torch.cuda.is_available())\"",
                            "然后再次运行 python run.py guide",
                        ],
                    )
                else:
                    next_action = GuideAction(
                        "text-index", "READY", "MinerU 已就绪，下一步构建 jtvauctions_text。",
                        "python run.py build-text --projects jtvauctions",
                        [
                            "若提示 collection 已存在，先运行 guide 复核，不要加 --recreate-text",
                            "中断后可重复同一命令；caption_cache 会复用",
                        ],
                    )
            else:
                cache_root = resolve_path(config_path, config["paths"]["vendor_cache"]) / "vdocrag"
                missing_cache = [project for project in projects if not (cache_root / f"{project}.npz").is_file()]
                details["vdocrag_cache_missing"] = missing_cache
                if missing_cache:
                    next_action = GuideAction(
                        "vdocrag-index", "READY", "文本和图像索引已就绪；预构建 VDocRAG 页面向量。",
                        "python run.py build-vdocrag --projects jtvauctions",
                        [
                            "首次会从 Hugging Face 下载权重；中断后会复用已下载分片",
                            "AMD ROCm 使用 eager attention，不需要安装 flash_attn",
                            "完成后再次运行 guide",
                        ],
                    )
                else:
                    output_root = resolve_path(config_path, config["paths"]["output"])
                    counts = _result_counts(config, output_root)
                    details["generation_results"] = counts
                    pair = [FULL, WITHOUT_DRA]
                    if any(counts[name]["complete"] < counts[name]["expected"] for name in pair):
                        next_action = GuideAction(
                            "generate-crest", "READY", "基础索引齐全；先成对生成 AUCMR full 与 w/o cross-slot。",
                            'python run.py generate --resume --methods "AUCMR (CREST full)" "CREST w/o cross-slot"',
                            ["完成或中断后运行 guide 查看结果缺口"],
                        )
                    else:
                        baseline_order = [
                            "LVLM-Direct", "TextRAG-Elaborate", "VDocRAG-Elaborate",
                            "ViDoRAG-Elaborate", "ReAct-Elaborate",
                        ]
                        incomplete = next((
                            name for name in baseline_order
                            if counts[name]["complete"] < counts[name]["expected"]
                        ), None)
                        if incomplete:
                            next_action = GuideAction(
                                "generate-baseline", "READY",
                                f"下一项生成 {incomplete}（{counts[incomplete]['complete']}/{counts[incomplete]['expected']} 已完成）。",
                                f'python run.py generate --resume --methods "{incomplete}"',
                                ["完成或中断后再次运行 guide"],
                            )
                        else:
                            evaluation_files = [
                                output_root / name for name in (
                                    "evaluation_cohort.json", "evaluation_audit.json",
                                    "aggregated_metrics.json", "table_l1.tex", "table_l2_consistency.tex",
                                )
                            ]
                            details["evaluation_files"] = {
                                path.name: path.is_file() for path in evaluation_files
                            }
                            latest_generation = _latest_generation_mtime(output_root)
                            evaluation_current = all(
                                path.is_file() and path.stat().st_mtime >= latest_generation
                                for path in evaluation_files
                            )
                            details["evaluation_current"] = evaluation_current
                            if not evaluation_current:
                                next_action = GuideAction(
                                    "evaluate", "READY", "7 种方法 × 9 个候选用例结果齐全；开始 L1/L2 裁判评测。",
                                    "python run.py evaluate",
                                    [
                                        "裁判失败会留下 evaluation_audit.json 并停止聚合",
                                        "修复接口后重复 evaluate；生成结果不会重跑",
                                    ],
                                )
                            else:
                                next_action = GuideAction(
                                    "complete", "DONE", "自动生成与 L1/L2 评测全部完成。",
                                    None,
                                    [
                                        "检查 outputs/evaluation_cohort.json",
                                        "检查 outputs/evaluation_audit.json",
                                        "论文表在 outputs/table_l1.tex 与 table_l2_consistency.tex",
                                        "L3/L4 仍需人工标注与专家评审",
                                    ],
                                )

    payload = {"next": asdict(next_action), "checks": details}
    if json_output:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"[{next_action.status}] 阶段：{next_action.stage}")
        print(next_action.message)
        if next_action.command:
            print(f"\n下一条命令：\n{next_action.command}")
        if next_action.branches:
            print("\n完成条件 / 异常分支：")
            for branch in next_action.branches:
                print(f"- {branch}")
        print("\n完成上述动作后，再运行：python run.py guide")
    return 0


def safe_stem(actor: str, use_case: str) -> str:
    return re.sub(r"[^\w\-.]+", "", f"{actor}_{use_case}".replace(" ", "_")) or "unnamed"


def evidence_payload(uc: Any, method: str) -> dict:
    refs = {
        ref for slot in uc.slots.values() for claim in slot.claims for ref in claim.evidence_refs
    }
    cards = {card.card_id: card for card in uc.all_evidence_cards}
    return {
        "use_case_name": uc.use_case_name,
        "actor": uc.actor,
        "method": method,
        "evidence_summary": uc.evidence_summary,
        "referenced_card_ids": sorted(refs),
        "evidence_cards": [card.to_dict() for card in cards.values()],
    }


def write_crest_result(uc: Any, method: str, output_root: Path, project: str) -> str:
    method_dir = "aucmr_full" if method == FULL else "crest_without_dra"
    out_dir = output_root / method_dir / project
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = safe_stem(uc.actor, uc.use_case_name)
    main_path = out_dir / f"{stem}.json"
    ev_path = out_dir / f"{stem}-evidence.json"
    main_data = uc.to_dict()
    main_data["method"] = method
    main_path.write_text(json.dumps(main_data, ensure_ascii=False, indent=2), encoding="utf-8")
    ev_path.write_text(json.dumps(evidence_payload(uc, method), ensure_ascii=False, indent=2), encoding="utf-8")
    return str(main_path)


def run_generation(config: dict, config_path: Path, methods: list[str], resume: bool = False) -> None:
    output_root = resolve_path(config_path, config["paths"]["output"])
    use_cases = config["experiment"]["use_cases"]
    missing_by_method: dict[str, set[tuple[str, str, str]]] = {}
    if resume:
        counts = _result_counts(config, output_root)
        missing_by_method = {
            method: {
                (str(item["project"]), str(item["use_case"]), str(item["actor"]))
                for item in counts.get(method, {}).get("missing", [])
            }
            for method in methods
        }

    def needs(method: str, item: dict) -> bool:
        if not resume:
            return True
        identity = (str(item["project"]), str(item["use_case"]), str(item["actor"]))
        return identity in missing_by_method.get(method, {identity})

    crest_methods = [method for method in methods if method in {FULL, WITHOUT_DRA}]
    if crest_methods:
        from services.model_registry import registry
        from crest import CRESTOrchestrator
        from crest.agents import cross_slot_revision
        for item in use_cases:
            needed_crest = [method for method in crest_methods if needs(method, item)]
            if not needed_crest:
                print(f"SKIP complete: {item['actor']} / {item['use_case']}")
                continue
            registry.set_collection(item["project"], item.get("file_names"))
            retrieval_fn = registry.get_retrieval_adapter()
            provider = registry.get_model_provider(think=False)
            if set(needed_crest) == {FULL, WITHOUT_DRA}:
                orchestrator = CRESTOrchestrator(
                    retrieval_fn=retrieval_fn,
                    file_names=registry.file_names,
                    topk=registry.topk,
                    provider=provider,
                    total_doc_pages=registry.total_pages,
                    dra_max_rounds=0,
                )
                without_dra = orchestrator.elaborate(item["actor"], item["use_case"])
                print(write_crest_result(without_dra, WITHOUT_DRA, output_root, item["project"]))
                full = copy.deepcopy(without_dra)
                is_unresolvable = any(
                    flag.flag_type == "unresolvable_use_case" for flag in full.quality_flags
                )
                if not is_unresolvable:
                    full = cross_slot_revision(
                    actor=item["actor"], use_case_name=item["use_case"], uc=full,
                    file_names=registry.file_names, topk=registry.topk,
                    retrieval_fn=retrieval_fn, provider=provider,
                        max_rounds=int(config["algorithm"].get("dra_max_rounds", 2)),
                    )
                orchestrator._build_evidence_summary(full)
                print(write_crest_result(full, FULL, output_root, item["project"]))
            else:
                method = needed_crest[0]
                dra_rounds = int(config["algorithm"].get("dra_max_rounds", 2)) if method == FULL else 0
                orchestrator = CRESTOrchestrator(
                    retrieval_fn=retrieval_fn, file_names=registry.file_names,
                    topk=registry.topk, provider=provider,
                    total_doc_pages=registry.total_pages, dra_max_rounds=dra_rounds,
                )
                uc = orchestrator.elaborate(item["actor"], item["use_case"])
                print(write_crest_result(uc, method, output_root, item["project"]))

    baseline_methods = [method for method in methods if method in BASELINES]
    if baseline_methods:
        from eval.baselines import get_all_baselines
        runners = get_all_baselines(str(output_root / "baselines"), baseline_methods)
        for baseline in runners:
            for item in use_cases:
                if not needs(baseline.name, item):
                    print(f"SKIP complete: {baseline.name} / {item['actor']} / {item['use_case']}")
                    continue
                print(baseline.run_and_save(
                    item["use_case"], item["actor"], item["project"], item.get("file_names")
                ))


def run_evaluation(config: dict, config_path: Path) -> None:
    from eval.run_experiments import ExperimentRunner, generate_latex_table_l1, generate_latex_table_l3
    output_root = resolve_path(config_path, config["paths"]["output"])
    runner = ExperimentRunner(output_dir=str(output_root), baseline_names=[])
    results = runner.collect_crest_results(str(output_root))
    methods = selected_methods(config, None)
    results, cohort = runner.select_paper_cohort(results, methods)
    (output_root / "evaluation_cohort.json").write_text(
        json.dumps(cohort, ensure_ascii=False, indent=2), encoding="utf-8",
    )
    evaluation = config.get("experiment", {}).get("evaluation", {})
    method_metrics = runner.compute_all_metrics(
        results,
        run_nli=bool(evaluation.get("run_nli", False)),
        run_l2=bool(evaluation.get("run_l2_judge", False)),
    )
    (output_root / "evaluation_audit.json").write_text(
        json.dumps(runner.evaluation_audit(method_metrics), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    aggregated = runner.aggregate_and_report(method_metrics)
    report = output_root / "aggregated_metrics.json"
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps(aggregated, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_root / "table_l1.tex").write_text(generate_latex_table_l1(aggregated), encoding="utf-8")
    (output_root / "table_l2_consistency.tex").write_text(generate_latex_table_l3(aggregated), encoding="utf-8")
    print(report)


def main() -> int:
    parser = argparse.ArgumentParser(description="AUCMR unified server experiment entry point")
    parser.add_argument(
        "command",
        choices=(
            "guide", "preflight", "text-preflight", "build-image", "build-text", "build-vdocrag",
            "generate", "evaluate", "all",
        ),
    )
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--methods", nargs="+", help="Override experiment.methods for this run")
    parser.add_argument("--skip-preflight", action="store_true")
    parser.add_argument(
        "--resume", action="store_true",
        help="Skip generation items that already have both result and evidence JSON files",
    )
    parser.add_argument("--json", action="store_true", help="Machine-readable output for guide")
    parser.add_argument(
        "--projects", nargs="+", help="Limit build-image/build-text/build-vdocrag to these projects",
    )
    parser.add_argument(
        "--recreate-text", action="store_true",
        help="Drop and rebuild an existing {project}_text collection",
    )
    parser.add_argument(
        "--force-mineru", action="store_true",
        help="Run MinerU again even when a content-list JSON already exists",
    )
    args = parser.parse_args()
    config, config_path = load_config(args.config)
    logging.basicConfig(
        level=getattr(logging, str(config.get("runtime", {}).get("log_level", "INFO")).upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    methods = selected_methods(config, args.methods)
    if args.command == "guide":
        return guide(config, config_path, json_output=args.json)
    if args.command == "text-preflight":
        return text_preflight(config, config_path, args.projects)
    if args.command == "build-image":
        run_image_build(config, config_path, args.projects)
        return 0
    if args.command == "build-text":
        if not args.skip_preflight:
            status = text_preflight(config, config_path, args.projects)
            if status and config.get("runtime", {}).get("fail_fast", True):
                return status
        run_text_build(
            config, config_path, args.projects, args.recreate_text, args.force_mineru,
        )
        return 0
    if args.command == "build-vdocrag":
        vdocrag_methods = ["VDocRAG-Elaborate"]
        if not args.skip_preflight:
            status = preflight(config, config_path, vdocrag_methods)
            if status and config.get("runtime", {}).get("fail_fast", True):
                return status
        run_vdocrag_build(config, args.projects)
        return 0
    if args.command == "preflight":
        return preflight(config, config_path, methods)
    if not args.skip_preflight:
        status = preflight(config, config_path, methods)
        if status and config.get("runtime", {}).get("fail_fast", True):
            return status
    if args.command in ("generate", "all"):
        run_generation(config, config_path, methods, resume=args.resume)
    if args.command in ("evaluate", "all"):
        run_evaluation(config, config_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
